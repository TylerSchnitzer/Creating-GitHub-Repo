#ifndef PQUEUETYPE_FLAG
#define PQUEUETYPE_FLAG
#include <iostream>
#include <string>
#include <cstddef>

using namespace std;

template <class elementType>
class pQueueType
{
	private:
		struct nodeType
		{
			elementType payLoad;
			nodeType* next;

			nodeType()
			{
				next=NULL;
				return;
			}
		};
		nodeType *root;

		void altcreate(nodeType *p)
		{
			if( p )
			{
				nodeType *q;
				q=p->next;

				p->next=NULL;
				delete p;
				altcreate( q );
			}
			return;
		}

		void altprint(nodeType *p)
		{
			if( p )
			{
				cout<<p->payLoad<<'\n';
				altprint(p->next);
			}
			return;
		}
		
	public:
		pQueueType()
		{
			root=NULL;
			
			return;
		}
		
		~pQueueType()
		{
			altcreate(root);

			return;
		}
		
		void create()
		{
			altcreate(root);
			root=NULL;

			return;
		}
		
		bool isRoom()
		{
			return true;
		}
		
		void put(elementType &e)
		{
			if( !isThere(e) )
			{
				nodeType *p, *q;
				p=root;
				q=NULL;
				
				while( p && p->payLoad>e)
				{
					q=p;
					p=p->next;
				}

				if( !q )
				{
					root=new nodeType;
					root->payLoad=e;
					root->next=p;
				}  
				else
				{
					q->next=new nodeType;
					q=q->next;
					q->payLoad=e;
					q->next=p;
				}
			}
			return;
		}
		
		bool isThere(elementType &e)
		{
			nodeType *p;
			p=root;
			while( p && p->payLoad != e )
				p=p->next;
			
			return p;
		}
		
		void remove(elementType &e)
		{
			if(isThere(e))
			{
				nodeType *p, *q;
				p=root;
				q=NULL;

				while(p->payLoad != e)
				{
					q=p;
					p=p->next;
				}

				if(!q)
					root=root->next;
				else
					q->next=p->next;
				
				p->next=NULL;
				delete p;
			}
		}
		
		void print()
		{
			cout<<"\n\n**************\n";
			if(root)
				altprint(root);
			else
				cout<<"Null root.\n";

			return;
		}
};
#endif